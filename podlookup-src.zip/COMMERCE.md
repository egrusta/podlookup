# PodLookup — Commercial Architecture (DRY RUN)

Status: planning document only. No commerce is connected. No supplier,
payment, age-verification, shipping, analytics, webhook, secret or credential
exists in this project. Nothing here transacts.

## 1. Current catalog model (as built)

`PRODUCTS` entries in `index.html` carry: `id, name, brand, family,
category, art, price, was, img, rating, reviews, badge, blurb,
compatibility[], specs[]`. Compatibility facts (`COMPATIBILITY`, `ENTITY`,
`MASTER`) are derived from the verified dataset, not from products.

## 2. Field gap analysis — real product vs current fields

Present and reusable: product id, brand, display name, family, category,
marketing copy, imagery path, illustrative price.

Missing for real commerce (DO NOT invent values — all [APPROVAL NEEDED]
via supplier/partner data):
- SKU / GTIN / MPN per sellable unit
- Pack quantity as structured data (currently embedded in name/specs text)
- Live price + VAT treatment + `was`/promotion source
- Stock status / quantity (currently illustrative; JSON-LD deliberately
  omits `availability` per audit rule)
- Supplier SKU + supplier identity + cost price
- Image license status per photo (currently manufacturer shots used for
  illustration only; footer states third-party ownership)
- Weight/dimensions (shipping calculation)
- Compliance metadata per SKU: MHRA notification reference, TPD/TRPR
  status, nicotine strength/volume where applicable, labelling checks
- Real ratings/reviews (current values are illustrative demo data; JSON-LD
  deliberately omits `aggregateRating` per audit rule)

## 3. Separation: compatibility data vs commercial data

- Compatibility layer (`MASTER` → `COMPATIBILITY` → `ENTITY` → GEO pages,
  Finder, guides) must never depend on shop availability. It stays useful
  with zero products listed (UNKNOWN/empty states already handle this).
- Commercial layer (future): a separate product/supplier feed keyed by SKU
  that references compatibility entities by `brand|device` / platform key,
  never the reverse. If the feed is down, compatibility pages render with
  the existing "not listed" states; if compatibility data is missing for a
  SKU, no fit claim is ever rendered.
- Prices/stock live only in the commercial feed. No price or stock value is
  baked into compatibility content, guides, FAQ or structured data beyond
  the current illustrative demo placeholders (which must be replaced, not
  extended).

## 4. Future flow (design only, not implemented)

Product → live stock/price check → basket → age verification gate →
checkout/payment → order creation (server-side price snapshot) →
supplier fulfilment → shipping/tracking → customer notification.

Order of gates is deliberate: age verification must pass before payment
can be taken under UK rules; price/stock must be re-validated server-side
at order creation because the client cart resolves prices live.

## 5. Implementable now without credentials

- Everything already built: compatibility reference, Finder, basket with
  persistence, launch-list capture, informational footer pages.
- Copy-only honesty states (already live): disabled checkout with
  launch-list path, illustrative-data disclaimers, prototype notices.
- Future-safe prep needing no credentials: SKU-shaped `id` values (already
  slug-style), keeping pack quantity out of display names when the real
  feed is designed, retaining the JSON-LD `availability`/
  `aggregateRating` omissions until real data exists.

## 6. Requires external accounts/partners [APPROVAL NEEDED]

- Payment provider (UK card acquirer/PSP) + webhook endpoint + PCI scope
- Age-verification provider (18+ challenge + verification at checkout)
- Supplier/wholesaler agreement(s) + fulfilment terms + cost/stock feed
- Shipping carrier account(s) + rates/tracking integration
- Transactional email provider (order confirm, shipping, failure notices)
- Order storage/backend (database + admin) — nothing order-like may live
  in localStorage beyond the current anonymous basket
- MHRA/TPD product compliance per SKU + responsible-person arrangement
- Analytics/monitoring + cookie consent to cover it
- Company details: legal entity, address, registration, VAT number,
  trading terms, returns policy, privacy notice — none exist here and none
  are invented in this document

## 7. Cart assessment

Current shape `[{id, qty}]` in `localStorage "podlookup-cart"`, prices
resolved live from `PRODUCTS` at render. Verdict: clean and
checkout-compatible; left untouched. Price-at-add snapshots and
server-side re-validation belong to order creation, not to this demo
cart, so no backwards-compatible change was justified.

## 8. Failure states (design contracts for later)

- Out of stock: block add / flag line, offer launch/notify path, never
  take payment against unreserved stock.
- Price changed since basket: re-validate at checkout, show old vs new,
  require explicit accept.
- Supplier unavailable: hide/disable affected SKUs, keep compatibility
  content fully available.
- Age verification failed: hard-stop before payment, no order created,
  plain-language reason, retry path.
- Payment failed: no order, basket preserved, retry without re-entering
  age evidence where lawful.
- Checkout interrupted: basket persists locally (as today); resume from
  basket, never from a half-created order.
- Order creation failed after payment attempt: reconcile before any
  fulfilment call; customer notified with reference, never silent.

## 9. Legal/compliance placeholders (reviewed, not written)

Footer INFO_PAGES (Delivery, Contact, Privacy, Terms), prototype notices
and illustrative-data disclaimers are demo copy only. They assert no
company details, no registration numbers, no addresses, no compliance
status. Real policies require a lawyer/company secretary before launch.

## 10. Launch checklist (UK)

1. Legal entity, VAT, business bank account [APPROVAL NEEDED]
2. Supplier agreements + SKU feed (price/stock/cost) [APPROVAL NEEDED]
3. MHRA notifications verified per SKU [APPROVAL NEEDED]
4. Image licenses or replacement photography [APPROVAL NEEDED]
5. Real ratings/reviews source or removal of demo values [APPROVAL NEEDED]
6. Payment provider + webhooks [APPROVAL NEEDED]
7. Age-verification provider [APPROVAL NEEDED]
8. Shipping accounts + rate tables [APPROVAL NEEDED]
9. Transactional email + templates [APPROVAL NEEDED]
10. Order backend + admin + reconciliation [APPROVAL NEEDED]
11. Real policies (terms/privacy/returns/cookies) [APPROVAL NEEDED]
12. Analytics + consent banner [APPROVAL NEEDED]
13. Replace all illustrative prices/stock/ratings, enable availability
    and aggregateRating structured data from the live feed
14. Re-run dataset audit; pen-test checkout; soft-launch to launch list
