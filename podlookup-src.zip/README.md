# VapeHub UK — front-end prototype

A **demonstration storefront** for a UK refillable-vape retailer, styled to look
like a premium production shop rather than a wireframe. It is *not* a shop: no
payments, no checkout, no nicotine products and no age verification. Every price,
rating and stock value is illustrative demo data.

## Where things live

- `main.pjs` — only the `$meta` block (page title, description, tags) plus the
  `dynamic(inputs)` hook that makes the title/description/social image respond
  to the canonical query parameter. Perchance owns `<head>`, so SEO metadata
  belongs here rather than in the HTML.
- `index.html` — the entire site: semantic markup, embedded `<style>` design
  system and the embedded `<script>` application. Self-contained (no frameworks,
  no CDN imports).
- `src/img/*.jpg` — the seven product photographs used by the catalogue and the
  hero. Same-origin so they load reliably everywhere the generator is previewed.

Everything in `index.html` is body content only (no `<html>`/`<head>`/`<body>`
tags — Perchance adds those).

## Design system

Defined as CSS custom properties in the `:root` block of the embedded stylesheet:

- `--bg:#0b0d10` dark charcoal, `--panel` / `--panel-2` raised surfaces
- `--accent:#2f7dff` electric blue (single UI accent)
- `--txt` / `--txt-2` / `--muted` white → light grey type scale
- Ecosystem cards carry a per-brand hue that stays inside the blue family
  (XROS `#2f7dff`, XLIM `#17a9e6`, Caliburn `#6f7bff`)

Product imagery is **real product photography** on white plates (see below).
`deviceArt()` / `podArt()` remain in the script purely as an offline fallback:
if an image fails to load, `window.__artFallback` / the hero `onerror` swap in a
procedural SVG so the card never shows a broken image.

## Product photography

The catalogue uses genuine manufacturer/supplier product shots. Sources were
official retail product pages (authorised UK supplier listings for Vaporesso,
OXVA and Uwell). Each original was **auto-trimmed to the product bounding box
plus a ~9% margin, then re-framed as a centred 1000×1000 white (#FFFFFF) square**
so every card shows the product at a consistent scale and proportion.

Photography is used for illustration/demonstration only and remains the property
of the respective brands; this is stated in the site footer.

Rebuild recipe (if photos ever need re-doing): download the white-background
product images, detect the non-white bounding box, pad by ~9%, composite onto a
1000×1000 white canvas, and overwrite `src/img/*.jpg` with matching filenames.

## Data model — how to replace the catalogue

All content is plain JavaScript arrays at the top of the embedded script. Edit
these and the whole storefront re-renders; no markup changes needed.

- `PRODUCTS` — id, name, brand, family, category, art (`device` | `mini` | `pod`),
  `img` (path to the photo), price, was, rating, reviews, badge, blurb,
  compatibility[], specs[]
- `ECOSYSTEMS` — the three homepage cards (key must match a `family`)
- `COMPATIBILITY` — brand → device → { family, pods, ohms[], note }. This is the
  single source of truth for the Compatibility Finder **and** the guides.
- `GUIDES` — guide cards + full article HTML shown in the modal
- `FAQS` — accordion content, also emitted as FAQPage structured data

`accent` is assigned automatically from `familyAccent()`, so a new family needs
an entry in `ECOSYSTEMS` (or it falls back to the brand blue).

## SEO expansion — enrichment-only architecture

No new URL types. All five search intents are sections on existing canonical
routes, so no thin doorway pages are created:

- Device pages (`devices/<brand>/<device>`) and compatibility pages
  (`compatibility/<brand>/<device>`) each gained three blocks built only from
  MASTER/ENTITY: resistance options (device ohms vs pod ohms, kept separate),
  pod alternatives (same-platform devices with resistance tables, or an honest
  no-alternative note for G2/G3/A3), troubleshooting (links to the recorded
  guides, no invented causes). UNKNOWN devices (original Caliburn) show none.
- Platform pages (`platforms/<slug>`) gained a per-pod-product table naming
  exactly which devices each replacement pod fits.
- Finder result "Next steps" gained a pod-platform page link.

Helpers: `resistanceBlockHtml`, `alternativesBlockHtml`,
`troubleshootingBlockHtml`, `podDevicesBlockHtml` in index.html. No routing,
dataset, cart, audit or metadata changes were needed.

## Conversion readiness

Every canonical GEO page carries a "Find your pod" Finder CTA; the
not-found page links the Finder too. Adding from a product modal opens the
basket drawer; the drawer offers an honest launch-list path that scrolls to
and focuses the footer signup. The shop empty state links the Finder. Modal
and drawer move keyboard focus to their close buttons on open. Quantity
steppers are 40px touch targets.

## Production SEO readiness

- Every route emits title + meta description + canonical + OG/Twitter tags
  (verified matrix: home, both indexes, all brands/platforms/entities,
  not-found). Home canonical/og:url = pageBase; entity canonicals =
  `?p=` paths; not-found emits no canonical + `noindex, follow`.
- `main.pjs $meta.dynamic` is the served-HTML twin of the in-page
  `setGeoMeta`; the audit asserts they match. Served-side execution happens
  on the platform at save time — re-check titles after saving.
- Finder deep-links are `#hash` only: never crawled, never in canonicals
  or og:url (verified). No infinite indexable URL space.
- JSON-LD carries no `availability`, `aggregateRating`, `review` or
  `award`; demo prices appear as Offer price only, with on-page
  illustrative-data disclaimers. Enable availability/ratings only from the
  live feed (see COMMERCE.md).
- `robots.txt` and sitemap are platform-level (robots = only
  `Disallow: /api/downloadGenerator`; no `perchance.org/sitemap.xml`) and
  cannot be set per generator.
- Favicon + theme-color are runtime-injected (`setBrandHead`, inline SVG
  data URL, no new dependency): real for visitors, invisible to raw-HTML
  crawlers since Perchance owns `<head>`.
- The unsaved editor preview carries a platform-injected
  `noindex, nofollow` (not ours — ours emits nothing on normal routes).
  Confirm it is gone on the saved URL after publishing.

## Red-team hardening (pre-launch QA)

- `sanitizeCart()` runs on every cart render: drops unknown product ids,
  drops non-integer/zero/negative quantities, merges duplicate lines and
  caps quantity at 99. Fixes a boot crash (`p.price` TypeError) reachable
  via hand-edited localStorage ghost ids.
- `addToCart` and drawer `data-inc` cap quantity at 99.
- Launch-list email rejects angle brackets (write-only value, but no
  HTML-like strings are stored).
- Modal and drawer restore keyboard focus to the opening element on close.

## Structured data

`injectStructuredData()` writes JSON-LD into `#product-schema` (an `ItemList` of
`Product`/`Offer` nodes, each with an `image`) and `#faq-schema` (`FAQPage`),
both generated from the arrays above. They are placeholders — regenerate from
live data before launch.

## Interaction map (event delegation on `document`)

`data-view` product modal · `data-add` add to basket · `data-guide` guide modal ·
`data-cat` category chip · `data-family` ecosystem filter · `data-shop-family`
filter + scroll to shop · `data-clear` clear filter · `data-close-modal`.

State lives in `state = { query, category, family }`; the header search box and
the in-shop search box are kept in sync by `setQuery()`.

## Known scope limits (by design)

- Basket persists in the browser via localStorage but checkout stays disabled.
- No age gate, no payments, no backend.
- Footer Info pages (Delivery, Contact, Privacy, Terms) are demo modal copy.
- Brand names are used descriptively to explain pod compatibility only; no
  third-party retailer content, copy or logos are reproduced.

## Verified-data (GEO) layer — Phase 3B

A verified-data layer now sits on top of the storefront:

- `MASTER` (near the top of the embedded script) mirrors the standalone
  `src/data/master-verified-dataset.json` (13 devices, 5 platforms). It is the
  single source of truth; `COMPATIBILITY` and the entity model (`ENTITY`) are
  derived from it at boot. **Note:** the standalone JSON file is not present in
  this workspace — the embedded `MASTER` object is the authoritative copy at
  runtime, and its `sourceOfTruth` label still names that path.
- Canonical GEO routes are query-param based (one page each, no invented
  routes): `?p=devices`, `?p=devices/<brand>/<device>`, `?p=compatibility`,
  `?p=platforms/<slug>`, `?p=brands/<slug>`.
- Guides: the `pods-work` guide carries the how-to-fill / how-to-prime /
  how-to-replace answers (Phase 3B-2A) plus four troubleshooting answers
  (Phase 3B-2B): "Why is my pod leaking?", "Why does my pod taste burnt?",
  "Why is my pod not working?" and "Why am I getting weak flavour?". Every
  cause/action is source-supported or answered "Information currently
  unavailable."; a recorded design property is never restated as a cause; pod
  resistance and device resistance stay separate; no procedure, interval,
  lifespan, puff count, wattage or resistance recommendation is invented.
- Guides: the `which-pod` guide is the **compatibility decision guide**
  (Phase 3B-2C): four question-led sections — "How do I check whether a pod
  fits my device?", "Can I use a pod from the same brand in my device?",
  "Does the pod resistance determine compatibility?" and "What if my exact
  device or pod is not listed?". Everything is drawn only from verified
  `MASTER` relationships: a pod fits a device only when MASTER records a
  shared pod platform. A same-brand relationship, a shared family name,
  similar resistance or a similar look are never presented as compatibility;
  pod resistance and device resistance are shown as separate specifications
  and never combined into a fit rule. Where the exact relationship is not
  recorded the answer is "Information currently unavailable." (e.g. the
  original Uwell Caliburn, and OXVA XLIM C, which is documented but not in
  the verified set). Links use only the canonical routes above — no new
  routes.
- **Discovery foundation (Phase 3B-2F).** The home page gains a *Compatibility
  reference* section (`#reference` → `#refGrid`), rendered from the live entity
  model: one column each for the reference indexes, brands, pod platforms and
  priority guides, linking only the canonical routes above. The `<noscript>`
  fallback is the crawlable copy of the same data: brand / pod-platform lists, a
  device table (now carrying a **Compatible replacement pods (recorded)**
  column), a *Pod platforms and the devices that use them* table, a *Brands and
  their pod platforms* table, the guides, and question-led `dt`/`dd` answers for
  every platform ("Which devices use the X pod platform?"), the four which-pod
  decision questions and the four 3B-2B troubleshooting questions. Every value
  is read from `MASTER`; a device whose platform is UNKNOWN keeps the UNKNOWN
  marker and is never given a pod.
- **Last-modified signal.** Where the platform supplies the saved generator's
  own edit time (`__generatorLastEditTime` in the served URL), it is shown once
  as a footer line and set as `dateModified` on the `WebSite` JSON-LD node. When
  it is absent (as in the unsaved editor preview) neither is emitted — no date
  is ever fabricated.

### Platform limitations (recorded, not worked around)

- `robots.txt` is set by Perchance platform-wide (it contains only
  `Disallow: /api/downloadGenerator`) — a generator cannot add a `Sitemap:`
  line or any directive.
- There is no generator-level sitemap or feed endpoint: `perchance.org/sitemap.xml`
  returns 404 and no RSS/Atom route exists. The generator therefore does **not**
  simulate any of these and creates no fake discovery URLs. Discovery endpoints
  are platform-level and out of scope for generator code.

### Audits (run in the browser console)- `window.__masterDatasetAudit()` — re-checks the rendered structures against
  `MASTER`; currently **112 checks**, target 0 errors / 0 warnings. Result is
  stored on `window.__masterDatasetAuditResult`. Section 21 is the Phase 3B-2B
  troubleshooting check: the four questions are present, each has a direct
  answer plus the recorded cause or the unavailable marker, the recorded leak
  design properties appear and are flagged as not causes, canonical links
  resolve, and no unsupported procedure/timing/lifespan/wattage/resistance/
  health/recommendation content appears. Section 22 is the Phase 3B-2C
  compatibility decision check: the four decision questions are present; every
  device→platform→pod row equals MASTER; same-brand rows equal only the
  platforms MASTER records for that brand; same-brand is never presented as
  compatibility; pod and device resistance stay separate; UNKNOWN and the named
  unrecorded cases are preserved; forbidden wording (wattage/voltage/
  recommendation/nicotine/medical/health/lifespan/puff count/replacement
  interval) is absent; and every canonical link type is present and resolves.
  Section 23 is the Phase 3B-2D AI-discoverability check: question-led Q&A
  content for the "Which pod fits X?", "What pods fit this device?", "Can I use
  this pod in this device?" and 3B-2B troubleshooting questions exists as
  crawlable text; canonical links resolve to real entities; the emitted
  structured data (WebSite, Organization, BreadcrumbList, Product/ItemList,
  FAQPage, Question/Answer) is internally consistent with `MASTER`; no noindex
  meta is emitted on normal routes; no unsupported AI/SEO ranking or citation
  claims appear anywhere in the shipped content; UNKNOWN stays explicit and is
  never converted to an inferred answer; and device/platform relationships are
  identical across device, platform, brand, compatibility and guide views. It
  asserts only technical crawlability and semantic readability — robots.txt,
  sitemaps, indexing and actual AI/search citation are platform-level/external
  and are deliberately not claimed.
  Section 24 is the Phase 3B-2F discovery check: the home reference hub links
  every brand, every pod platform and all three indexes and links resolve; the
  crawlable `<noscript>` fallback's device→pod, platform→devices and
  brand→platforms tables equal `MASTER`/`ENTITY` and preserve UNKNOWN; the
  priority platform, which-pod and troubleshooting questions are present as
  crawlable text; no sitemap / robots.txt / RSS / Atom / XML discovery endpoint
  is simulated anywhere in crawlable content; the last-modified line and the
  `WebSite` `dateModified` appear only when the platform supplied a time and
  never otherwise; and guide route ids are unique.
- `window.__geoAudit` — data-integrity result object written by
  `auditEntities()` (0 errors / 0 warnings).
